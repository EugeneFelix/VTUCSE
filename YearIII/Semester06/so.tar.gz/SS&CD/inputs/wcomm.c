#include<stdio.h>

//djjfjd
/* djfjbfbf */

int main() {
    /* irfjk3kr */
    // djdnejdj

    return 0;
}
