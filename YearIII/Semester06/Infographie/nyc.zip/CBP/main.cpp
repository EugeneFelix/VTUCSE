#include "cube_spin.h"
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    handler();
    return 0;
}
